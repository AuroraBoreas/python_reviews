from __future__ import annotations
import dataclasses
import sys

@dataclasses.dataclass
class CircleThereom:
    def __init__(self) -> None:
        pass

    def angle_at_center_theorem(self, inscribed_angle: float) -> float:
        if inscribed_angle < 0 or inscribed_angle > sys.float_info.max:
            raise ValueError("angle should not be less than 0")
        return inscribed_angle * 2

    def get_angle_of_intersecting_secants(self, a: float, b: float) -> float:
        if a < 0 or b < 0 or (a > sys.float_info.max) or (b > sys.float_info.max):
            raise ValueError("angle should not be less than 0")
        return abs(a - b) / 2
    
    def inscribed_quadratic_lateral_diagon(self, a: float) -> float:
        return 180 - a