from __future__ import annotations
import dataclasses
import math
from typing import Any, Callable

import sympy


@dataclasses.dataclass
class Point:
    _x: int = dataclasses.field(init=True, repr=True, compare=True)
    _y: int = dataclasses.field(init=True, repr=True, compare=True)

    def __init__(self, x: int | float, y: int | float) -> None:
        self._x = x
        self._y = y

    @property
    def x(self) -> int | float:
        return self._x

    @x.setter
    def x(self, val: int | float) -> None:
        self._x = val

    @property
    def y(self) -> int | float:
        return self._y

    @y.setter
    def y(self, val: int | float) -> None:
        self._y = val


@dataclasses.dataclass
class LineSegment:
    _p1: Point = dataclasses.field(init=True, repr=True)
    _p2: Point = dataclasses.field(init=True, repr=True)

    def __init__(self, p1: Point, p2: Point) -> None:
        self._p1 = p1
        self._p2 = p2

    def incrementX(self) -> int | float:
        return self._p2.x - self._p1.x

    def incrementY(self) -> int | float:
        return self._p2.y - self._p1.y

    def distance(self) -> int | float:
        return math.sqrt(self.incrementX()**2 + self.incrementY()**2)

    def slope(self) -> int | float:
        return self.incrementY() / self.incrementX()

    def angle(self) -> int | float:
        return math.atan(self.slope())

    def middle_point(self) -> Point:
        return Point((self._p1.x + self._p2.x) / 2, (self._p1.y + self._p2.y) / 2)

    def general_form(self) -> Callable[[int | float, int | float], float]:
        """return a general form of a line: ax + by + c = 0

        Returns
        -------
            function
        """
        return lambda x, y: self.slope()*x - y + (self._p1.y - self.slope()*self._p1.x)

    def point_to_line_distance(self, p: Point) -> float:
        """return the distance between a given point and a give line
        + reference: https://www.chilimath.com/lessons/advanced-algebra/distance-between-point-and-line-formula/

        Parameters
        ----------
        p
            point with coordinates(x0, y0)

        Returns
        -------
            point to line distance: distance = |a*x0 + b*y0 + c| / sqrt(a**2 + b**2),

            where a = slope, b = -1
        """
        return abs(self.general_form()(p.x, p.y)) / math.sqrt(self.slope()**2 + 1)


@dataclasses.dataclass
class Polygon:
    """A method for finding the area of any polygon when the coordinates of its vertices are known.

    ### method
    + First, number the vertices in order, going either clockwise or counter-clockwise, starting at any vertex.

    1. Make a table with the x,y coordinates of each vertex. Start at any vertex and go around the polygon in either direction. Add the starting vertex again at the end. You should get a table that looks like the leftmost gray box in the figure above.

    2. Combine the first two rows by:
        1. Multiplying the first row x by the second row y. (red)
        2. Multiplying the first row y by the second row x (blue)
        3. Subtract the second product form the first.
    3. Repeat this for rows 2 and 3, then rows 3 and 4 and so on.
    4. Add these results, make it positive if required, and divide by two.

    ### Limitations

    This method will produce the wrong answer for self-intersecting polygons, 
    where one side crosses over another, as shown on the right. 

    It will work correctly however for
    1. triangles
    2. regular and irregular polygons
    3. convex or concave polygons

    ### reference
    link: https://www.mathopenref.com/coordpolygonarea.html

    """
    _points: list[Point] = dataclasses.field(init=True, compare=True)

    def __init__(self, points: list[Point]) -> None:
        if len(points) < 3:
            raise ValueError
        self._points = points

    def area(self) -> float:
        """return area of a Polygon with points

        Returns
        -------
            area of a Polygon
        """
        total: int | float = 0
        self._points.append(self._points[0])
        for i in range(0, len(self._points) - 1):
            total += self._points[i].x*self._points[i +
                                                    1].y - self._points[i].y*self._points[i + 1].x
        return abs(total) / 2


class QuadraticEqn:
    def __init__(self, a: int | float, b: int | float, c: int | float) -> None:
        if a == 0:
            raise ValueError
        x, y = sympy.symbols('x y', real=True)
        self.eqn = a*x**2 + b*x + c

# class MyTriangle:
#     def __init__(self, a: sympy.Point, b: sympy.Point, c: sympy.Point) -> None:
#         self._triangle: sympy.Triangle = sympy.Triangle(a, b, c)

#     def sides(self) -> list[int | float]:
#         return self._triangle.sides

#     @property
#     def area(self) -> float:
#         return self._triangle.area


class Limit:
    """Limit properties: additive, communitive, 
    """

    f = sympy.Function('f')

    def __init__(self) -> None:
        from sympy import x, c, L
        self.limit = L
        self.expr = sympy.limit(self.f(x), x, c)

    @property
    def limit(self) -> Any:
        return self.limit

    @property
    def expr(self) -> Any:
        return self.expr

    def __add__(self, other: Limit) -> Any:
        return self.limit + other.limit

    def __sub__(self, other: Limit) -> Any:
        return self.limit - other.limit

    def __mul__(self, other: Limit) -> Any:
        return self.limit * other.limit

    def __div__(self, other: Limit) -> Any:
        return self.limit / other.limit

    def pow(self, m: int, n: int) -> Any:
        return self.limit**(m / n)

    def intermediate_value_theorem(self) -> str:
        """📚this is intermediate value theorem.
        
        💡it also indicates how to find a tangent of a given function xd

        Returns
        -------
            string
        """
        return (
            "given: suppose f(x) is continuous on an  interval I; a, b are any two points of I;\n" +
            "when: if y0 between f(a) and f(b)\n" +
            "then: there exists a number c between a and b such that f(c) = y0;"
        )


def triangle_inequality() -> str:
    return "|a + b| <= |a| + |b|"

class Difference(Limit):
    """📚difference is derived from Limit xd

    Limit operations / rules also applies on difference xd

    Parameters
    ----------
    Limit
        Limit object
    """
    def differentiable(self) -> str:
        return "smooth"
    
    def not_differentiable(self) -> str:
        return "corner, cusp, vertical, discontinuity"

