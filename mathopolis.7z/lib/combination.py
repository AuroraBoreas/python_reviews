from __future__ import annotations
import dataclasses
import math


@dataclasses.dataclass
class Combinition:
    """A Permutation is an ordered combination
    
    ### difference
    + when order matters, it is a permutation;
    + when order does not matter, it is a combination;

    ### feature
    + repetition is allowed;
    + repetition is not allowed;

    ### author
    + @ZL, 20230629

    ### changelog
    + v0.01, initial build

    ### reference
    + https://www.mathsisfun.com/combinatorics/combinations-permutations.html

    """
    _n: int             = dataclasses.field(init=True, repr=True)
    _choose: int        = dataclasses.field(init=True, repr=True)
    _isordered: bool    = dataclasses.field(init=True, repr=True)
    _isrepeatable: bool = dataclasses.field(init=True, repr=True)

    def __init__(self, n: int, choose: int, isordered: bool, isrepeatable: bool) -> None:
        self._n            = n
        self._choose       = choose
        self._isordered    = isordered
        self._isrepeatable = isrepeatable

    def compute(self) -> int | float:
        if self._isordered and self._isrepeatable:          # permutation with repetition
            return math.pow(self._n, self._choose)
        if self._isordered and not self._isrepeatable:      # permutation without repetition -> nPr
            return math.perm(self._n, self._choose)
        if not self._isordered and not self._isrepeatable:  # combination without repetition -> binomial distribution nCr
            return math.comb(self._n, self._choose)
        if not self._isordered and self._isrepeatable:      # combinations with repetition
            return math.factorial(self._choose + self._n - 1) / (math.factorial(self._choose) * math.factorial(self._n - 1))
        else:
            raise ValueError
        
def client_code() -> None:
    for c in [
        Combinition(10, 3, True, True),     # 10^3 = 1,000
        Combinition(16, 3, True, False),    # P(16, 3) = 3,360
        Combinition(16, 3, False, False),   # C(16, 3) = 560
        Combinition(5, 3, False, True),     # C^(5, 3) = 35
    ]:
        print(c.compute())

def main() -> None:
    client_code()

if __name__ == '__main__':
    main()