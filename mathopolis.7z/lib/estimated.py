from abc import ABC, abstractmethod


class Base:
    def __init__(self, n: float, decimal_places: int) -> None:
        if decimal_places < 1:
            raise ValueError("decimal places should be >= 1")
        self._n = n
        self._dp = decimal_places

    def get_exclusive_upper(self) -> float:
        return self._n + 5 / (10 ** self._dp)

    def get_inclusive_lower(self) -> float:
        return self._n - 5 / (10 ** self._dp)

class Measurement(ABC):
    @abstractmethod
    def get_true_area(self) -> str:
        raise NotImplementedError

class Triangle(Measurement):
    def __init__(self, base: Base, height: Base) -> None:
        self._base = base
        self._height = height

    def get_true_area(self) -> str:
        return "area=[{0},{1})".format(
            .5 * self._base.get_inclusive_lower() * self._height.get_inclusive_lower(),
            .5 * self._base.get_exclusive_upper() * self._height.get_exclusive_upper()
        )

class Rectangle(Measurement):
    def __init__(self, width: Base, height: Base) -> None:
        self._width = width
        self._height = height

    def get_true_area(self) -> str:
        return "area=[{0}, {1})".format(
            self._width.get_inclusive_lower() * self._height.get_inclusive_lower(),
            self._width.get_exclusive_upper() * self._height.get_exclusive_upper()
        )

class Trapeziod(Measurement):
    def __init__(self, top: Base, bottom: Base, height: Base) -> None:
        self._top = top
        self._bottom = bottom
        self._height = height
    
    def get_true_area(self) -> str:
        return "area=[{0}, {1})".format(
            .5 * self._height.get_inclusive_lower() * (self._top.get_inclusive_lower() + self._bottom.get_inclusive_lower()),
            .5 * self._height.get_exclusive_upper() * (self._top.get_exclusive_upper() + self._bottom.get_exclusive_upper())
        )

def client_code(width: float, height: float, decimal_places: int) -> None:
    rm: Rectangle = Rectangle(Base(width, decimal_places), Base(height, decimal_places))
    print(rm.get_true_area())

def main() -> None:
    client_code(11, 9, 1)

if __name__ == '__main__':
    main()