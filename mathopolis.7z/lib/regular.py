from collections import namedtuple
import dataclasses
from enum import Enum
import math
import sys

SideLength = namedtuple('SideLength', ['trigSideType', 'length'])

class TrigSideType(Enum):
    SIDE = 1
    APOTHEM = 2
    RADIUS = 3

@dataclasses.dataclass
class RegularPolygon:
    """calculate regular polygon properties based on given sides and side length.
    
    ### author
    + @ZL, 20230701

    ### changelog
    + v0.03, bugfix

    ### reference link:
    + mathopolis
    
    """
    _sides: int = dataclasses.field(init=True, repr=True)
    _side_length: SideLength = dataclasses.field(init=True, repr=True)

    def __init__(self, sides: int, side_length: SideLength) -> None:
        if sides < 3 or sides > sys.maxsize or not isinstance(sides, int):
            raise ValueError("sides of polyon must be >= 3 and a natural number")
        self._sides  = sides
        self._side_length = side_length
        
    def get_side_length(self) -> float:
        match self._side_length.trigSideType:
            case TrigSideType.SIDE: return self._side_length.length
            case TrigSideType.APOTHEM: return self._side_length.length *  2 / math.tan(self.get_btm_angle())
            case TrigSideType.RADIUS: return self._side_length.length * 2 * math.cos(self.get_btm_angle())
            case _: raise ValueError

    def get_radius(self) -> float:
        match self._side_length.trigSideType:
            case TrigSideType.SIDE: return self._side_length.length * .5 / math.cos(self.get_btm_angle())
            case TrigSideType.APOTHEM: return self._side_length.length / math.sin(self.get_btm_angle())
            case TrigSideType.RADIUS: return self._side_length.length
            case _: raise ValueError

    def get_apothem(self) -> float:
        match self._side_length.trigSideType:
            case TrigSideType.SIDE: return self._side_length.length * .5 * math.tan(self.get_btm_angle())
            case TrigSideType.APOTHEM: return self._side_length.length
            case TrigSideType.RADIUS: return self._side_length.length * math.sin(self.get_btm_angle())
            case _: raise ValueError

    def get_top_angle(self) -> float:
        return math.pi * 2 / self._sides
    
    def get_btm_angle(self) -> float:
        return math.pi * (1 / 2 - 1 / self._sides)
    
    def get_area(self) -> float:
        """return the area of a given regular polygon

        Returns
        -------
            the area of regular polygon (sq unit)
        """
        return self._sides / 4 * self.get_side_length()* self.get_side_length() * math.tan(self.get_btm_angle())

def client_code() -> None:
    polygon = RegularPolygon(5, SideLength(TrigSideType.APOTHEM, 17))
    print(polygon.get_area())
    print(polygon.get_side_length())

def main() -> None:
    client_code()

if __name__ == '__main__':
    main()