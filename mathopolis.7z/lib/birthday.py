
import dataclasses
import sys


@dataclasses.dataclass
class SharedBirthdayProbability:
    """
    There are eleven people in a room.

    What are the chances that any of them share the same birthday?
    
    Assume 365 days in a year.

    ### author
    @ZL, 20230522

    ### changelog
    + v0.01, initial build

    ### reference
    @Ref: https://www.mathsisfun.com/data/probability-shared-birthday.html
    """

    _population: int    = dataclasses.field(init=True, repr=True)
    _choice: int        = dataclasses.field(init=True, repr=True)

    def __init__(self, population: int, choice: int) -> None:
        """initialize an instance

        Parameters
        ----------
        population
            total number of people in a room.
        choice
            total choice

        Raises
        ------
        ArgumentError
            population must be greater than 2
        """
        if population < 2 or population > sys.maxsize:
            raise ValueError("'share' means at least two people present")
        self._population = population
        self._choice     = choice

    def compute(self) -> float:
        if self._choice < self._population:
            return 1
        numerator: int = 1
        denominator: int = self._choice ** (self._population - 1)
        for i in range(self._choice - self._population + 1, self._choice):
            numerator *= i
        return 1 - numerator / denominator

    def __str__(self) -> str:
        return "population={0:<2}, choice={1:<3}, probability={2:.3f}".format(
            self._population,
            self._choice,
            self.compute()
        )