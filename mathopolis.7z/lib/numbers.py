
from typing import Callable, ParamSpec, TypeVar


def fibonacci(n: int) -> list[int]:
    startpoint: list[int] = [0, 1]
    for _ in range(n):
        startpoint.append(startpoint[-2] + startpoint[-1])
    return startpoint

def get_least_start_index_of_consecutive_n_divisable_by_x(seq: list[int], n: int, x: int) -> int:
    P = ParamSpec('P')
    T = TypeVar('T')
    is_divisable_by_x: Callable[P, T] = lambda a, b: a % b == 0
    for i in range(len(seq)):
        try:
            if all(is_divisable_by_x(seq[i+j], x) for j in range(n)):
                return i
        except IndexError:
            return -1

def main() -> None:
    from itertools import accumulate
    n: int = 20
    seq: list[int] = list(accumulate(fibonacci(n)))
    print(get_least_start_index_of_consecutive_n_divisable_by_x(seq, 2, 11))


if __name__ == '__main__':
    main()
