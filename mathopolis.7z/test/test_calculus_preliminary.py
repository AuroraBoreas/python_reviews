import math
import sys
from typing import Any
sys.path.append('.')

import unittest
from lib.caag.preliminary import Point, LineSegment, Polygon, sympy, MyTriangle

class TestPoint(unittest.TestCase):
    def setUp(self) -> None:
        self.point = Point(1, 2)
    
    def test_x(self) -> Any:
        self.assertEqual(1, self.point.x)

    def test_y(self) -> Any:
        self.assertEqual(2, self.point.y)

    def test_set_x(self) -> Any:
        self.point.x = 0
        self.assertEqual(0, self.point.x)

    def test_set_y(self) -> Any:
        self.point.y = 0
        self.assertEqual(0, self.point.y)

class TestLineSegment(unittest.TestCase):
    def setUp(self) -> None:
        self.line = LineSegment(Point(0, 0), Point(1, 1))
    
    def test_distance(self) -> None:
        self.assertAlmostEqual(1.414, self.line.distance(), 3)

    def test_slope(self) -> None:
        self.assertAlmostEqual(1, self.line.slope())

    def test_middle_point(self) -> None:
        self.assertEqual(Point(0.5, 0.5), self.line.middle_point())

    def test_incrementX(self) -> None:
        self.assertEqual(1, self.line.incrementX())
    
    def test_incrementY(self) -> None:
        self.assertEqual(1, self.line.incrementY())

    def test_angle(self) -> None:
        self.assertEqual(math.pi / 4, self.line.angle())

    def test_point_to_line_distance(self) -> Any:
        line: LineSegment = LineSegment(Point(0, -2.5), Point(10/3, 0))
        self.assertLessEqual(2.0, line.point_to_line_distance(Point(0, 0)))

        line = LineSegment(Point(0, 5/-8), Point(5/6, 0))
        self.assertLessEqual(4.5, line.point_to_line_distance(Point(3, -4)))

        line = LineSegment(Point(0, 7), Point(-21/5, 0))
        self.assertLessEqual(9.6, line.point_to_line_distance(Point(10, 5)))

class TestPolygon(unittest.TestCase):
    def setUp(self) -> None:
        self._polygon = Polygon([
            Point(4, 10),
            Point(9, 7),
            Point(11, 2),
            Point(2, 2),
        ])

    def test_area(self) -> None:
        self.assertEqual(45.5, self._polygon.area())

class TestMyTriangle(unittest.TestCase):
    def setUp(self) -> None:
        self.myTriangle = MyTriangle(sympy.Point(1,2), sympy.Point(3,4), sympy.Point(5,6))
    
    def test_area(self) -> None:
        print(self.myTriangle.sides())
        # self.assertEqual(13, self.myTriangle.area)

def main() -> None:
    unittest.main()

if __name__ == '__main__':
    main()