import sys
sys.path.append('.')

import unittest
from lib.birthday import SharedBirthdayProbability

class TestBirthday(unittest.TestCase):
    def setUp(self) -> None:
        self.birthday = SharedBirthdayProbability(11, 365)

    def test_compute(self) -> None:
        self.assertAlmostEqual(0.141, self.birthday.compute(), 3)

def main() -> None:
    unittest.main()

if __name__ == '__main__':
    main()