from __future__ import annotations

import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')

from abc import ABC, abstractmethod
from typing import overload
@overload
def add(a: int, b: int) -> int: ...
@overload
def add(a: str, b: str) -> str: ...
@overload
def add(a: float, b: float) -> float: ...

def add(a: int | str | float, b: int | str | float) -> int | str | float:
    return a + b

class Base:
    @overload
    def __init__(self, a: int, b: int) -> None: ...

    @overload
    def __init__(self, a: str, b: str) -> None: ...

    def __init__(self, a: int | str, b: int | str) -> None:
        self.a = a
        self.b = b

    def __str__(self) -> str:
        return f'a = {self.a}, b = {self.b}'


class Fig(ABC):
    @abstractmethod
    def accept(self, v: Visitor) -> None:
        raise NotImplementedError()

class Dot(Fig):
    def accept(self, v: Visitor) -> None:
        v.visit(self)

class Shape(Fig):
    def accept(self, v: Visitor) -> None:
        v.visit(self)

class Visitor:
    @overload
    def visit(self, d: Dot) -> None: ...

    @overload
    def visit(self, s: Shape) -> None: ...

    def visit(self, f: Dot | Shape) -> None:
        logging.info(f'{self.__class__} : visited {f.__class__}')

def main() -> None:
    b: Base = Base(2,3)
    logging.info(b)
    logging.info(Base('hello','world'))

    d1: Dot = Dot()
    s1: Shape = Shape()
    v1: Visitor = Visitor()
    d1.accept(v1)
    s1.accept(v1)

if __name__ == '__main__':
    main()
