from __future__ import annotations

import polars as pl
from polars import DataFrame, Series, LazyFrame, Expr
import numpy as np
from datetime import datetime, timedelta, date
import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')
import time
from typing import Callable, Any, Dict
def timer(func: Callable) -> Callable:
    def timed(*args: Any, **kwargs: Any) -> Any:
        b: float = time.perf_counter()
        r: Any   = func(*args, **kwargs)
        e: float = time.perf_counter()
        logging.info('time elapsed(s): {0:5f}'.format(e - b))
        return r
    return timed

@timer
def polars_read_csv() -> None:
    df: DataFrame = pl.read_csv("data/iris.csv")
    logging.info(df.filter(pl.col("sepal_length") > 5)
        .groupby("species", maintain_order=True)
        .agg(pl.all().sum())
    )

@timer
def polars_lazy() -> None:
    df: DataFrame = pl.read_csv("data/iris.csv")
    logging.info(
        df.lazy()
        .filter(pl.col("sepal_length") > 5)
        .groupby("species", maintain_order=True)
        .agg(pl.all().sum())
        .collect()
    )

@timer
def polars_from_scratch() -> None:
    # with a tuple
    series: Series = pl.Series("a", [1, 2, 3, 4, 5])
    logging.info(series)
    # with a list
    series: Series = pl.Series([1, 2, 3, 4, 5])
    logging.info(series)
    # with a dataframe
    df = pl.DataFrame({"integer": [1, 2, 3],
                            "date": [
                                (datetime(2022, 1, 1)),
                                (datetime(2022, 1, 2)),
                                (datetime(2022, 1, 3))
                            ],
                            "float":[4.0, 5.0, 6.0]})

    logging.info(df)

def petit_dataframe01() -> DataFrame:
    return pl.DataFrame({"integer": [1, 2, 3],
                            "date": [
                                (datetime(2022, 1, 1)),
                                (datetime(2022, 1, 2)),
                                (datetime(2022, 1, 3))
                            ],
                            "float":[4.0, 5.0, 6.0]})

@timer
def polars_from_file() -> None:
    df: DataFrame = petit_dataframe01()
    df.write_csv('data/output.csv')
    # csv
    logging.info('=== csv, save no status ===')
    df_csv: DataFrame = pl.read_csv('data/output.csv')
    logging.info(df_csv)
    # ask polars to parse datetime
    df_csv: DataFrame = pl.read_csv('data/output.csv', parse_dates=True)
    logging.info('=== csv, parse datetime ===')
    logging.info(df_csv)
    # json
    df.write_json('data/output.json')
    df_json: DataFrame = pl.read_json('data/output.json')
    logging.info('=== json ===')
    logging.info(df_json)
    # parquet
    df.write_parquet('data/output.parquet')
    df_parquet: DataFrame = pl.read_parquet('data/output.parquet')
    logging.info('=== parquet ===')
    logging.info(df_parquet)

def petit_dataframe02() -> DataFrame:
    return pl.DataFrame({"a": np.arange(0, 8),
                   "b": np.random.rand(8),
                   "c": [datetime(2022, 12, 1) + timedelta(days=idx) for idx in range(8)],
                   "d": [1, 2.0, np.NaN, np.NaN, 0, -5, -42, None]
                  })

@timer
def polars_view_data() -> None:
    df: DataFrame = petit_dataframe02()
    logging.info("=== first view ===")
    logging.info(df)
    # head
    logging.info("=== head ===")
    logging.info(df.head(5))
    # tail
    logging.info("=== tail ===")
    logging.info(df.tail(5))
    # sample() to get an impression of the dataframe
    logging.info("=== sample ===")
    logging.info(df.sample(3))
    # describe
    logging.info(df.describe())

@timer
def polars_expr() -> None:
    df: DataFrame = petit_dataframe02()
    logging.info(
        df.select(
        # pl.col('*')
        pl.col(['a','b'])
        )
    )
    # select
    logging.info(
        df.select([
            pl.col('a'),
            pl.col('b')
        ]).limit(3)
    )
    logging.info(
        df.select([
            pl.exclude('a')
        ])
    )
    # filter
    logging.info(
        df.filter(
            pl.col('c').is_between(datetime(2022,12,2), datetime(2022,12,8)),
        )
    )
    logging.info(
        df.filter(
            (pl.col('a') <= 3) & (pl.col('d').is_not_nan())
        )
    )

def polars_with_columns() -> None:
    df: DataFrame = petit_dataframe02()
    # with_columns
    logging.info(
        df.with_columns([
            pl.col('b').sum().alias('e'),
            (pl.col('b') + 42).alias('b+42')
        ])
    )

def petit_dataframe03() -> DataFrame:
    return pl.DataFrame({
                    "x": np.arange(0, 8),
                    "y": ['A', 'A', 'A', 'B', 'B', 'C', 'X', 'X'],
                    # "z": np.arange(0, 8),
                    })

def polars_agg() -> None:
    df: DataFrame = petit_dataframe03()
    logging.info(
        df.groupby('y', maintain_order=True).count()
    )
    logging.info(
        df.groupby('y', maintain_order=True).agg([
            # pl.col('*').count().alias('count'),
            (pl
            .col('*')
            # .sum()
            # .alias('sum')
            )
        ])
    )
    # df: DataFrame = pl.DataFrame({
    #     "foo": ["one", "two", "two", "one", "two"],
    #     "bar": [5, 3, 2, 4, 1]
    #     })
    # logging.info(df.groupby("foo", maintain_order=True).agg([
    #         # pl.sum("bar").suffix("_sum"),
    #         (pl
    #         .col("bar")
    #         .sort()
    #         .tail(2)
    #         .sum()
    #         .suffix("_tail_sum")
    #         )
    #     ])
    # )

def polars_combining_operations() -> None:
    df: DataFrame = petit_dataframe02()
    df_x: DataFrame = df.with_column(
        (pl.col('a') * pl.col('b')).alias('a * b')
    ).select([
        pl.all().exclude(['c', 'd'])
    ])
    logging.info(df_x)

    df_y: DataFrame = df.with_columns(
        (pl.col('a') * pl.col('b')).alias('a * b')
    ).select([
        pl.all().exclude('d')
    ])
    logging.info(df_y)


def polars_combining_dataframes() -> None:
    df1: DataFrame = petit_dataframe02()
    df2: DataFrame = petit_dataframe03()
    logging.info(f'{df1.shape}, {df2.shape}')
    # joins, id-like columns: 'a', 'x'
    logging.info(
        df1.join(df2, left_on='a', right_on='x')
    )
    # concat: vectical, horizontal
    # concat, join, extend, hstack, vstack
    logging.info(
        # pl.concat([df1, df2], how='vertical') # error, dimension mismatches
        pl.concat([df1, df2], how='horizontal')
    )

def petit_dataframe04() -> DataFrame:
    np.random.seed(12)

    return pl.DataFrame(
        {
            "nrs": [1, 2, 3, None, 5],
            "names": ["foo", "ham", "spam", "egg", None],
            "random": np.random.rand(5),
            "groups": ["A", "A", "B", "C", "B"],
        }
    )

def polars_counter_unique_values() -> None:
    out: DataFrame = petit_dataframe04().select([
        pl.col('names').n_unique().alias('unique_names_1'),
        pl.col('names').unique().count().alias('unique_names_2'),
    ])
    logging.info(out)
    out = petit_dataframe04().select([
        pl.sum('random').alias('sum'),
        pl.min('random').alias('min'),
        pl.max('random').alias('max'),
        pl.col('random').max().alias('other_max'),
        pl.median('random').alias('median'),
        pl.mean('random').alias('mean'),
        pl.std('random').alias('std dev'),
        pl.var('random').alias('variance')
    ])
    logging.info(out)
    # filter and conditionals
    out = petit_dataframe04().select([
        pl.col('names').filter(pl.col('names').str.contains('am$')).count().alias('names_am$'),
        pl.col('names').filter(pl.col('names').str.contains('am$')).count().alias('other_names_am$'),
    ])
    logging.info(out)
    # when...then...otherwise
    out = petit_dataframe04().select([
        pl.when(pl.col('random') > .5).then(0).otherwise(pl.col('random') * pl.sum('nrs'))
    ])
    logging.info(out)
    # window expr
    logging.info(
        petit_dataframe04().select([
            # pl.col('*'),
            # (pl
            #     .col('random')
            #     .sum()
            #     .over('groups')
            #     .alias('sum[random]/groups')
            # ),
            (pl
                .col('random')
                .list()
                .over('groups')
                .alias('random/name')
            ),
        ])
    )

def polars_expr_contexts() -> None:
    df: DataFrame = petit_dataframe04()
    # select context: Series must have the same length or have a length of 1
    # with_columns also has the same context
    out: DataFrame = df.select([
        pl.sum('nrs'),
        pl.col('names').sort(),
        pl.col('names').first().alias('first name'),
        (pl.mean('nrs') * 10).alias('10xnrs'),
    ])
    logging.info(out)

    out = df.with_columns([
        pl.sum('nrs').alias('nrs_sum'), # broadcasting
        pl.col('random').count().alias('count'), # broadcasting
    ])
    logging.info(out)

    # groupby may yiled results of any length
    out = df.groupby('groups').agg([
        pl.sum('nrs'),
        pl.col('random').count().alias('count'),
        pl.col('random').filter(pl.col('names').is_not_null()).sum().suffix('_sum'),
        pl.col('names').reverse().alias(('reversed names')),
    ])
    logging.info(out)

def petit_dataframe05() -> DataFrame:
    dtypes: Dict = {
        'first_name': pl.Categorical,
        'gender': pl.Categorical,
        'type': pl.Categorical,
        'state': pl.Categorical,
        'party': pl.Categorical,
    }
    dataset = (pl
            .read_csv('data/legislators-historical.csv', dtypes=dtypes)
            .with_column(pl.col('birthday').str.strptime(pl.Date, strict=False))
    )
    return dataset


def polars_dont_kill_parallelization() -> None:
    df = petit_dataframe05()
    # basic agg
    q: LazyFrame = (
        df.lazy()
        .groupby('first_name')
        .agg([
            pl.count(),
            pl.col('gender').list(),
            pl.first('last_name'),
        ])
        .sort('count', reverse=True)
        .limit(5)
    )
    logging.info(q.collect())

    # turn it up to a notch
    q = (
        df.lazy()
        .groupby('state')
        .agg([
            (pl.col('party') == 'Anti-Administration').sum().alias('anti'),
            (pl.col('party') == 'Pro-Administration').sum().alias('pro'),
        ])
        .sort('pro', reverse=True)
        .limit(5)
    )
    logging.info(q.collect())
    # or
    q = (
        df.lazy()
        .groupby(['state', 'party'])
        .agg(pl.count('party').alias('count'))
        .filter((pl.col('party') == 'Anti-Administration')|(pl.col('party') == 'Pro-Administration'))
        .sort('count', reverse=True)
        .limit(5)
    )
    logging.info(q.collect())
    # filter groups. GROUP BY ... HAVING...
    # using UDF to create exprs, DONT apply a custom function over a Series during runtime of the query
    def compute_age() -> Expr:
        return date(2021, 1, 1).year - pl.col('birthday').dt.year()

    def avg_birthday(gender: str) -> Expr:
        return compute_age().filter(pl.col('gender') == gender).mean().alias(f'avg {gender} birthday')

    q = (
        df.lazy()
        .groupby(['state'])
        .agg([
            avg_birthday('M'),
            avg_birthday('F'),
            (pl.col('gender') == 'M').sum().alias('# male'),
            (pl.col('gender') == 'F').sum().alias('# female'),
        ])
        .limit(5)
    )
    logging.info(q.collect())
    # we could SORT and GROUPBY
    def get_person() -> Expr:
        return pl.col('first_name') + pl.lit(' ') + pl.col('last_name')

    q = (
        df.lazy()
        .sort('birthday', reverse=True)
        .groupby(['state'])
        .agg([
            get_person().first().alias('youngest'),
            get_person().last().alias('oldest'),
            get_person().sort().first().alias('alphabetical_first'),
            pl.col('gender').sort_by('first_name').first().alias('gender'),
        ])
        .sort('state')
        .limit(5)
    )
    logging.info(q.collect())

def petit_dataframe06() -> DataFrame:
    return pl.DataFrame({
        'a': [1, 2, 3],
        'b': [0, 1, 2],
    })

def polars_folds() -> None:
    df: DataFrame = petit_dataframe06()
    logging.info(df.select([
        pl.all(),
        pl.fold(acc=pl.lit(0), f=lambda acc, x: acc + x, exprs=pl.col('*').alias('sum')),
        # pl.sum(['a', 'b']), # no, this is agg
        (pl.col('a') + pl.col('b')).alias('other_sum'),
        ])
    )
    logging.info(df.filter(
        pl.fold(
            acc=pl.lit(True),
            f=lambda acc, x: acc & x,
            exprs=pl.col('*') > 1,
        )
    ))

    logging.info(pl.DataFrame(
        {
            'a': ['a', 'b', 'c'],
            'b': [1, 2, 3]
        }
    ).select([
        pl.concat_str(['a', 'b'])
        ])
    )

def petit_dataframe07() -> DataFrame:
    return pl.read_csv('data/pokemon.csv')

def polars_window_functions() -> None:
    df: DataFrame = petit_dataframe07()
    # agg over...
    out: DataFrame = df.select(
        [
            "Type 1",
            "Type 2",
            pl.col("Attack").mean().over("Type 1").alias("avg_attack_by_type"),
            pl.col("Defense").mean().over(["Type 1", "Type 2"]).alias("avg_defense_by_type_combination"),
            pl.col("Attack").mean().alias("avg_attack"),
        ]
    )
    logging.info(out)
    # sort over...
    filtered: DataFrame = df.filter(pl.col("Type 2") == "Psychic").select(
        [
            "Name",
            "Type 1",
            "Speed",
        ]
    )
    logging.info(filtered)
    out = filtered.with_columns(
        [
            pl.col(["Name", "Speed"]).sort(reverse=True).over("Type 1"),
        ]
    )
    logging.info(out)
    # window expr rules
    """
    # aggregate and broadcast within a group
    # output type: -> Int32
    >>> pl.sum("foo").over("groups")

    # sum within a group and multiply with group elements
    # output type: -> Int32
    >>> (pl.col("x").sum() * pl.col("y")).over("groups")

    # sum within a group and multiply with group elements
    # and aggregate the group to a list
    # output type: -> List(Int32)
    >>> (pl.col("x").sum() * pl.col("y")).list().over("groups")

    # note that it will require an explicit `list()` call
    # sum within a group and multiply with group elements
    # and aggregate the group to a list
    # the flatten call explodes that list

    # This is the fastest method to do things over groups when the groups are sorted
    >>> (pl.col("x").sum() * pl.col("y")).list().over("groups").flatten()
    """

    # flattern window functions' result
    out = df.sort("Type 1").select(
        [
            pl.col("Type 1").head(3).list().over("Type 1").flatten(),
            pl.col("Name").sort_by(pl.col("Speed")).head(3).list().over("Type 1").flatten().alias("fastest/group"),
            pl.col("Name").sort_by(pl.col("Attack")).head(3).list().over("Type 1").flatten().alias("strongest/group"),
            pl.col("Name").sort().head(3).list().over("Type 1").flatten().alias("sorted_by_alphabet"),
        ]
    )
    logging.info(out)

def petit_dataframe08() -> DataFrame:
    return pl.DataFrame(
        {
            "student": ["bas", "laura", "tim", "jenny"],
            "arithmetic": [10, 5, 6, 8],
            "biology": [4, 6, 2, 7],
            "geography": [8, 4, 9, 7],
        }
    )

def polars_row_wise_computations() -> None:
    # compute the rank of all the columns except 'student'
    # collect wanted info into list, using pl.concat_list(...)
    df: DataFrame = petit_dataframe08()
    out: DataFrame = df.select(
        [
            pl.concat_list(pl.all().exclude('student')).alias('all_grades')
        ]
    )
    logging.info(out)
    # compute the rank in the list, using pl.col(...).arr.eval(...)
    rank_pct: Expr = pl.element().rank(reverse=True) / pl.col('').count()

    out = df.with_column(
        pl.concat_list(pl.all().exclude('student')).alias('all_grades')
    ).select([
        pl.all().exclude('all_grades'),
        pl.col('all_grades').arr.eval(rank_pct, parallel=True).alias('grades_rank'),
    ])
    logging.info(out)

def polars_nump_ufuncs() -> None:
    # ufuncs of np is vectorized
    df: DataFrame = pl.DataFrame({"a": [1, 2, 3], "b": [4, 5, 6]})
    out: DataFrame = df.select(
        [
            np.log(pl.all()).suffix("_log"),
        ]
    )
    logging.info(out)

def main() -> None:
    # polars_read_csv()
    # polars_lazy()
    # polars_from_scratch()
    # polars_from_file()
    # polars_view_data()
    # polars_expr()
    # polars_with_columns()
    # polars_agg()
    # polars_combining_operations()
    # polars_combining_dataframes()
    # polars_counter_unique_values()
    # polars_expr_contexts()
    # polars_dont_kill_parallelization()
    # polars_folds()
    # polars_window_functions()
    # polars_row_wise_computations()
    polars_nump_ufuncs()

if __name__ == '__main__':
    main()
