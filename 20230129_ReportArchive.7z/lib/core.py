from __future__ import annotations
from abc import ABCMeta, abstractmethod
import contextlib, logging, pathlib, re, sqlite3, shutil
import functools
import os
import yaml
from typing import Any, Generator, Optional, TypeVar, NewType
Path       = TypeVar('Path', str, bytes, pathlib.Path)
Connection = NewType('Connection', sqlite3.Connection)
Cursor     = NewType('Cursor', sqlite3.Cursor)
T          = TypeVar('T', int, str, bool)

logging.basicConfig(level=logging.INFO, format='%(message)s')

class PathException(Exception):
    def __init__(self, msg: str="File|DirectoryNotFound") -> None:
        super().__init__(msg)

@contextlib.contextmanager
def enter_table(conn: Connection) -> Cursor:
    cur: Cursor = conn.cursor()
    try:
        yield cur
    finally:
        cur.close()

class IArchiver(metaclass=ABCMeta):
    @abstractmethod
    def dump(self) -> None:
        raise NotImplementedError

    @abstractmethod
    def retrieve(self, *args: Any, **kwargs: Any) -> None:
        raise NotImplementedError

class Archiver(IArchiver):
    __srcFolder: list[Path] = None
    __db: Path              = None
    __dstFolder: Path       = None

    def __init__(self, config: Path) -> None:
        try:
            self._scout(config)
        except PathException:
            logging.info(f"{config} File Not Found")

    def _scout(self, config: Path) -> None:
        """Read environment variables and settings from yaml"""
        with open(config, 'r', encoding='utf8') as f:
            stream = yaml.safe_load(f)
            self.__srcFolder = stream['srcFolders']
            self.__db        = stream['db']
            self.__dstFolder = stream['dstFolder']

    def _get(self, folder: Path) -> Optional[Path]:
        """Enumerate all xxx.pptx files from a given root directory recursively

        Parameters
        ----------
        folder
            a given root directory

        Returns
        -------
            a Path like str
        """
        
        files: Generator[Path, None, None] = pathlib.Path(folder).rglob(r'*.pptx')
        pattern: str = r'^[0-9]{8}.*\.pptx'

        for file in files:
            if re.match(pattern, file.name):
                yield file

    def _fileToBytes(self, fromFile: Path) -> bytes:
        with open(fromFile, 'rb') as f:
            return f.read()

    def _bytesToFile(self, data: bytes, toFile: Path) -> None:
        with open(toFile, 'wb') as f:
            f.write(data)

    def _formatDate(self, date: str) -> Optional[str]:
        """Return a readable date format (military => civilian)

        Example
        -------
        >>> _formatDate("20210101")
        2021-01-01
        >>> _formatDate("2019")
        None
        """
        return f"{date[:4]}-{date[4:6]}-{date[6:]}" if len(date) == 8 else None
   
    def dump(self) -> None:
        """Store report files(*.pptx) into the database."""
        if not self.__db: raise ValueError
        sql_stmt_create, sql_stmt_insert = self._generate_sql_ddl_stmt()
        
        with sqlite3.connect(self.__db) as conn:
            with enter_table(conn) as cur:
                cur.execute(sql_stmt_create)
                for file in self._get(self.__srcFolder):
                    try:
                        temp: list[str] = file.name.split('_')
                        date: str       = self._formatDate(temp[0])
                        topic: str      = temp[1]
                        name: str       = ' '.join(temp[2:]).replace('.pptx','')
                        cur.execute(sql_stmt_insert, (date, topic, name, self._fileToBytes(file)))
                        logging.info(f"[Archive OK] File: {file.name}")
                    except IndexError:
                        conn.rollback()

    def _generate_sql_ddl_stmt(self) -> tuple[str, str]:
        sql_stmt_create: str = """CREATE TABLE IF NOT EXISTS report(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date VARCHAR(10),
            topic VARCHAR(20),
            name VARCHAR(50),
            file BLOB,

            UNIQUE(date, topic, name) ON CONFLICT REPLACE
        );"""

        sql_stmt_insert: str = """INSERT INTO report(date, topic, name, file)
            VALUES(?,?,?,?);"""

        return sql_stmt_create, sql_stmt_insert

    @functools.cache
    def retrieve(self,
        start: str,
        end: str,
        topic: str,
        name: str,
        id: int,
        save: bool) -> None:
        """Read data from the database."""
        if not self.__db: raise PathException
        sql_stmt, args = self._parse_sql_stmt(start, end, topic, name, id)

        idIdx: int    = 0
        dateIdx: int  = 1
        topicIdx: int = 2
        fileIdx: int  = 4
        counter: int  = 0
        fmt: str             = "{0:<10}\t{1:<10}\t{2:<15}\t{3}"
        heads: tuple[str]    = ('Id', 'Date', 'Topic', 'Name')
        punchline: list[str] = ["\N{BOX DRAWINGS HEAVY HORIZONTAL}" * 10] * 4

        self._reset(self.__dstFolder)
        with sqlite3.connect(self.__db) as conn:
            with enter_table(conn) as cur:
                rows = cur.execute(sql_stmt, args)
                logging.info(fmt.format(*heads))
                logging.info(fmt.format(*punchline))
                for row in rows:
                    counter += 1
                    logging.info(fmt.format(*row[idIdx : fileIdx]))
                    if save:
                        self._save(self.__dstFolder, row, dateIdx, topicIdx, fileIdx)
                logging.info(punchline[0])
                logging.info(f"Total: {counter}")

    def _parse_sql_stmt(self,
        start: str,
        end: str,
        topic: str,
        name: str,
        id: int) -> tuple[str, list[T]]:
        """Generate a pair of one sql statement(with placeholders) and corresponding args in terms of the provided parameters

        Parameters
        ----------
        start
            date range: start date
        end
            date range: end date
        topic
            topic(Pmod)
        name
            name(file name)
        id
            primary key in one database

        Example
        -------
        >>> _parse_sql_stmt('2018-10-01', '2022-12-31')
        ("SELECT * FROM report WHERE (date BETWEEN ? AND ?) ORDER BY date;", ['2018-10-01', '2022-12-31'])
        >>> _parse_sql_stmt('2018-10-01', '2022-12-31', topic='x')
        ("SELECT * FROM report WHERE (date BETWEEN ? AND ?) AND (topic LIKE ?) ORDER BY date;", ['2018-10-01', '2022-12-31', '%x%'])
        >>> _parse_sql_stmt('2018-10-01', '2022-12-31', name='y')
        ("SELECT * FROM report WHERE (date BETWEEN ? AND ?) AND (name LIKE ?) ORDER BY date;", ['2018-10-01', '2022-12-31', '%y%'])
        >>> _parse_sql_stmt('2018-10-01', '2022-12-31', 'x', 'y')
        ("SELECT * FROM report WHERE (date BETWEEN ? AND ?) AND (topic LIKE ?) AND (name LIKE ?) ORDER BY date;", ['2018-10-01', '2022-12-31', '%x%', '%y%'])

        Returns
        -------
            a tuple with one sql statement and corresponding args
        """

        sql_stmt: str = "SELECT * FROM report WHERE date >= ? AND date <= ?"
        args: list[T] = [start, end]
        like: str     = '%{}%'

        if topic != '*':
            sql_stmt += "AND topic LIKE ?"
            args.append(like.format(topic))
        if name != '*':
            sql_stmt += "AND name LIKE ?"
            args.append(like.format(name))
        if id > -1:
            sql_stmt += "AND id = ?"
            args.append(id)
        sql_stmt += "ORDER BY date;"
        return sql_stmt, args

    def _reset(self, dstFolder: Path=None) -> None:
        """Clear history files in `reports` directory, then make a new `reports` directory.

        Parameters
        ----------
        dstFolder, optional
            _description_, by default None
        """
        if dstFolder:
            p: pathlib.Path = pathlib.Path(dstFolder)
            try:
                if p.exists(): shutil.rmtree(p)
                p.mkdir()
            except PermissionError:
                logging.info("Download Failed. File is in use")

    def _save(self,
        dstFolder: Path,
        row: tuple[int | str | bytes],
        dateIdx: int,
        topicIdx: int,
        fileIdx: int) -> None:
        """Write BLOB(Binary Large Object) into a file.

        Example
        -------
        >>> _save(".", row, dateIdx, topicIdx, fileIdx)
        ... # doctest: +IGNORE
        """
        
        fileFormat: str       = "{0}\{1}_{2}.pptx"
        fileBlob: bytes       = row[fileIdx]
        formatedDate: str     = row[dateIdx].replace('-', '')
        formatedFileName: str = ' '.join(row[topicIdx : fileIdx]).replace('  ', ' ').replace(' ', '_')
        filename:str          = fileFormat.format(dstFolder, formatedDate, formatedFileName)
        try:
            self._bytesToFile(fileBlob, filename)
            os.startfile(filename)
        except PermissionError:
            logging.info("Write Failed. File is open")
